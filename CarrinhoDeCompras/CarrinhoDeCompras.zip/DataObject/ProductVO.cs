﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarrinhoDeCompras.DataObject
{
	public class ProductVO
	{
		public int id { get; set; }
		public string name { get; set; }
		public float price { get; set; }
	}
}

	